
//Width and height
var w = 1000;
var h = 750;
var padding=100;

// var dataset=stubRandomData()
// var dataset=[
   
p1=""
p2=""
p3=""
///all data

///data for chart
// mydata=new Array()
dataset=[]

function update_dataset(){
	dataset=[];
	for (var i in mydata) {
	// for(i=0;i<mydata.length;i++){
	    
	    group=[]
	    group.push(mydata[i][p1],mydata[i][p2],mydata[i][p3],mydata[i]['City']);
	    dataset.push(group)
	}
    // console.log(dataset)
 	
};

function update_parameters(a,b,c){
	p1=a
	p2=b
	p3=c
	update_dataset()
	// console.log('parameters updated')
};
update_parameters('GDP_per_capita','aqi','population')
console.log(dataset)


//Create scale functions
var xScale = d3.scale.linear()
	.domain([0, d3.max(dataset, function(d) { 
		// return d['aqi']; 
		return d[0]
	})])
	.range([padding, w - padding * 2]);


var yScale = d3.scale.linear()
	.domain([0, d3.max(dataset, function(d) { 
		// return d['pm2_5']; 
		return d[1]
	})])
	.range([h - padding, padding]);

var BubbleRadiusScale=d3.scale.linear()
    .domain([0, d3.max(dataset, function(d) { 
    	// return d['pm10']; 
    	return d[2]
    })])
    .range([3, 50]);

//Define X axis
var xAxis = d3.svg.axis()
	.scale(xScale)
	.orient("bottom")
	.ticks(5);

//Define Y axis
var yAxis = d3.svg.axis()
	.scale(yScale)
	.orient("left")
	.ticks(5);

//Create SVG element
var svg = d3.select("#chart")
	.append("svg")
	.attr("width", w)
	.attr("height", h);

//Define clipping path
// svg.append("clipPath") //Make a new clipPath
//   .attr("id", "chart-area") //Assign an ID
//   .append("rect") //Within the clipPath, create a new rect
//   .attr("x", padding) //Set rect's position and size…
//   .attr("y", padding)
//   .attr("width", w - padding * 3)
//   .attr("height", h - padding * 2);

//Create circles
svg.append("g") //Create new g
	.attr("id", "circles") //Assign ID of 'circles'
	// .attr("clip-path", "url(#chart-area)") //Add reference to clipPath
	.selectAll("circle")
	.data(dataset)
	.enter()
	.append("circle")
	.attr("cx", function(d) {
  		return xScale(d[0])
  	// return xScale(d[0])
	})
	.attr("cy", function(d) {
  		return yScale(d[1])
  	// return yScale(d[1])
	})
	.attr("opacity", 0.3)
	.attr("r", function(d) {
  		return BubbleRadiusScale(d[2])
  	// return BubbleRadiusScale(d[2])
	});

//Create X axis
svg.append("g")
	.attr("class", "x axis")
	.attr("transform", "translate(0," + (h - padding) + ")")
	.call(xAxis);

//Create Y axis
svg.append("g")
	.attr("class", "y axis")
	.attr("transform", "translate(" + padding + ",0)")
	.call(yAxis);

//On click, update with new data
function update_chart(){			
// d3.select("p")
//   .on("click", function() {
  
//     update_parameters("no2","o3","GDP_per_capita")

    //Update scale domains
    xScale.domain([0, d3.max(dataset, function(d) { return d[0]; })]);
    yScale.domain([0, d3.max(dataset, function(d) { return d[1]; })]);
    BubbleRadiusScale=d3.scale.linear()
    .domain([0, d3.max(dataset, function(d) { 
    	// return d['pm10']; 
    	return d[2]
    })])
    .range([3, 50]);
  	//Update X axis
    svg.select(".x.axis")
    	.transition()
    	.duration(1000)
    	.call(xAxis);
  
    //Update Y axis
    svg.select(".y.axis")
    	.transition()
    	.duration(1000)
    	.call(yAxis);
  
    //Update all circles
		svg.selectAll("circle")
			.data(dataset)
			.transition()
			.duration(1000)
			// .each("start", function() { // <-- Executes at start of transition
   //    			d3.select(this)

  	// 			// .attr("fill", "magenta")
  	// 			// .attr("r", 3);
			// })
			.attr("cx", function(d) {
	  			return xScale(d[0])
			})
			.attr("cy", function(d) {
				return yScale(d[1]);
			})
			// .attr("opacity", 0.3)
			
			// .tooltip(function(d, i) {
			//     var r, svg;
			//     r = +d3.select(this).attr('r');
			//     svg = d3.select(document.createElement("svg")).attr("height", 50);
			//     g = svg.append("g");
			//     g.append("rect").attr("width", r * 10).attr("height", 10);
			//     g.append("text").text("10 times the radius of the cirlce").attr("dy", "25");
			//     return {
			//       type: "tooltip",
			//       text: "Tip for circle of radius " ,
			//       detection: "shape",
			//       placement: "fixed",
			//       gravity: "right",
			//       position: [d.x, d.y],
			//       displacement: [r+2, -20],
			//       // mousemove: false
			//     };
			//   });
			
			// .each("end", function() { // <-- Executes at end of transition
			// 	d3.select(this)
			// 		.transition()
			// 	.duration(800)
				
			.attr("opacity", 0.3)
				// .attr("fill", "black")
				.attr("r", function(d) {
			  	return BubbleRadiusScale(d[2]);
				});
			// });
	// svg.selectAll("circle")
 //       .on("mouseover", handleMouseOver)
 //       .on("mouseout",handleMouseOut);
       
 //   svg.selectAll("path")
 //       .on("mouseover",handleMouseOver)
 //       .on("mouseout",handleMouseOut);
  };

;

///tooltips
var tooltip_div = d3.select('body')
        .append('div')
        .attr("class","bb_tooltips");

 var ToolTips=tooltip_div.append("div")
       .attr("class",'tooltip')
       .style("display","none")
       .style('position',"absolute")
       .style("fill","black");

   function handleMouseOver(d,i){
       ToolTips.style("display","inline")
       .html(d[3]+"<br />"+
       	p1+": "+d[0]+"<br />"+
       	p2+": "+d[1]+"<br />"+
       	p3+": "+d[2])
       // .attr("data-html", "true")
           .style("left", (d3.event.pageX - 30) + "px")
           .style("top", (d3.event.pageY - 32) + "px")
           .style("color","black")
           .style("cursor","default")
           .style("font-family","sans-serif")
           .style("padding","8px")
           .style("border-radius","5px")
           .style("box-shadow","0 0 5px rgba(0,0,0,0.3)")
           .style("background","rgba(255,255,255,0.8)");
   }
   
   function handleMouseOut(d,i){
       ToolTips.style("display", "none");
   }

   svg.selectAll("circle")
       .on("mouseover", handleMouseOver)
       .on("mouseout",handleMouseOut);
       
   svg.selectAll("path")
       .on("mouseover",handleMouseOver)
       .on("mouseout",handleMouseOut);



input1=document.getElementById("p1-input");
input1.oninput=function(){
		console.log(input1.value)
		p1=input1.value
		update_parameters(p1,p2,p3);
		update_chart()
   }
input2=document.getElementById("p2-input");
input2.oninput=function(){
		console.log(input1.value)
		p2=input2.value
		update_parameters(p1,p2,p3);
		update_chart()
   }
input3=document.getElementById("p3-input");
input3.oninput=function(){
		console.log(input1.value)
		p3=input3.value
		update_parameters(p1,p2,p3);
		update_chart()
   }



